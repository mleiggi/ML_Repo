
def read_file():
    
    """
The read_file function opens sowpods.txt and reads it with the code given in
the prompt.
    """
    with open("sowpods.txt","r") as infile:
        raw_input = infile.readlines()
        data = [datum.strip('\n') for datum in raw_input]
    return data

def score_word(tiles):

    """
The score_word function searches the word list for words that can be made with
our input tiles and scores them. It returns a tuple. 
    """
    tiles = tiles.upper()
    scores = {"a": 1, "c": 3, "b": 3, "e": 1, "d": 2, "g": 2,
         "f": 4, "i": 1, "h": 4, "k": 5, "j": 8, "m": 3,
         "l": 1, "o": 1, "n": 1, "q": 10, "p": 3, "s": 1,
         "r": 1, "u": 1, "t": 1, "w": 4, "v": 4, "y": 4,
         "x": 8, "z": 10}
# data is the list of words from the sowpods file.
    data = read_file()
# words_to_add will be the list of words and scores to use at the end.         
    words_to_add = []
# This for loop loops through each word in the data list.
    for word in data:
# the check below makes sure the word is not longer that the number of 
# tiles. If it is, then the word can be skipped.
        if len(word) <= len(tiles):
            i = 0
            temp_score = []
            tiles_list = list(tiles)
            for letter in word:
# The loop makes the tiles into a list to use the .pop() function to pop tiles
# once they are used. It includes statements for wildcards as well.
# If all condition fails, the word is invalid and the loop breaks
                if letter in tiles_list:
                   x = str(tiles_list.pop(tiles_list.index(letter))).lower()
                   temp_score.append(scores[x])
                   if len(word) - i == 1:
                       word_with_score = (sum(temp_score), word)
                       words_to_add.append(word_with_score)
   
                elif '?' in tiles_list:
                    tiles_list.pop(tiles_list.index('?'))
                    if len(word) - i == 1:
                       word_with_score = (sum(temp_score), word)
                       words_to_add.append(word_with_score)
                    
                elif '*' in tiles_list:
                    tiles_list.pop(tiles_list.index('*'))
                    if len(word) - i == 1:
                       word_with_score = (sum(temp_score), word)
                       words_to_add.append(word_with_score)
                    
                else:
                    break
                i += 1 

    words_to_add = sorted(words_to_add, key = lambda entry: (-entry[0], entry[1]))
    return (words_to_add, len(words_to_add))

if __name__ == '__main__':
    result = score_word('ABC*')
    print(result)

