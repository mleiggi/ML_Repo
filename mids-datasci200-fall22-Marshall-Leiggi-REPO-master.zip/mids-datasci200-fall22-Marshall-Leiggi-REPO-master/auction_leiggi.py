"""
Marshall Leiggi
October 2022
W200 Project 1
This document holds the User and Auction classes to be used in the auction.
It uses shuffle from random, numpy (as np), and the bidder from
bidder_leiggi
"""
from random import shuffle
import numpy as np

class User:
    """
    The User is generated with a random probability from np.random.uniform.
    The probability can be checked by printing the user. The bidder cannot
    see the probability of each user.
    """
    def __init__(self):
        self.__probability = np.random.uniform()

    def __repr__(self):
        return f"{self}"

    def __str__(self):
        return f"User {self.__probability}"

    def show_ad(self):
        """
        This returns True if the below random choice is within the probability
        of the user clicking (self.__probability) and False if not.
        This represents the user clicking an add or not.
        """
        return np.random.choice([True, False], p = [self.__probability, 1 - self.__probability])

class Auction:
    """
    The Auction class holds everything needed to run the auction. I initialize
    the bidders balances as zero using a list.
    """
    def __init__(self, users, bidders):
        self.users = users
        self.bidders = bidders
        self.balances = dict([(self.bidders.index(bidder), 0) for bidder in bidders])

    def __repr__(self):
        return f"{self}"

    def __str__(self):
        return f"The auction is running with {self.users} users and {self.bidders} bidders."

    def execute_round(self):
        """
        This contains the loop for the auction, along with all the calls to
        bidder and user needed to run the auction. The first for loop is the
        main auction loop that executes for the number of rounds which is held
        in bidders.num_rounds. I pull this from the first bidder so it works
        with one bidder.
        """
        # picking a random user
        user_id = np.random.randint(0, len(self.users))
        # generating list of bids from bidders
        bids = [self.bidders[i].bid(user_id) for i in range(len(self.bidders))]
        print(bids)
        # ordering the bids to pull the second highest later
        ordered_bids = sorted(bids)
        # setting the winning bet amount as a variable for readability
        winning_bid_amt = max(bids)
        # checking if the list has more than 1 winning bid
        if bids.count(winning_bid_amt) > 1:
            winners_list = []
            # I make a list of winners and shuffle it for random selection
            for bid in range(len(bids)):
                # bid is the bidders id, or the index in the bids list
                if bids[bid] == winning_bid_amt:
                    winners_list.append(bid)
            shuffle(winners_list)
            # after shuffling, winners_list[0] is the index of the winning bidder
            winning_bid_index = winners_list[0]
        # else executes if there is only one highest bid
        else:
            winning_bid_index = bids.index(max(bids))
        # if the list of bids list has multiple bids, grab the second highest
        # from the ordered list. This will return the right amount even if
        # there is a tie for highest bid.
        if len(ordered_bids) > 1:
            cost = ordered_bids[-2]
        # else executes if there is only one bidder
        else:
            cost = ordered_bids[0]
        # click is True or False depending on if the user clicks
        # the probability is decided by the user.show_ad method
        click = self.users[user_id].show_ad()
        # This loop updates the bidders as to if they won and what the
        # winning bid is. The winner gets to know if the user clicked and
        # the their balance is updated.
        for pos in range(len(self.bidders)):
            if pos == winning_bid_index:
                self.bidders[pos].notify(True, cost, click)
                # if the user clicks, int(click) = 1
                # if the user doesn't click int(click) = 0
                # the bidder's cost is removed and they get +1 if the
                # user clicked, +0 if not
                self.balances[pos] += (int(click) - cost)
                # I update the balances rounded to 3 digits.
                self.balances[pos] = round(self.balances[pos],3)
            else:
                # the losers do not get to know if the user clicked
                self.bidders[pos].notify(False, cost, None)
