"""
Marshall Leiggi
October 2022
W200 Project 1
This document holds the bidder class to be used in the auction
"""
import numpy as np

class Bidder:
    """
    The bidder class decides how much to bid in the auction.
    I will use the times clicked/appearences to determine how much to bet.
    More clicks = higher bet.
    """
    def __init__(self, num_users, num_rounds = False):
        if num_rounds != False:
            self.num_rounds = num_rounds
        self.num_users = num_users
        self.bidamt = np.random.uniform(0,.5)
        self.user_dict = {}
        self.user_id = None
        self.clicked = None
        self.auction_winner = None

    def __repr__(self):
        return f"{self}"

    def __str__(self):
        return f"Bid amount: {self.bidamt:.3f}"

    def bid(self, user_id):
        """
        This class returns the bid in the self.bidamt variable.
        If there is data on the user clicking I decide the amount to bet
        based on the ratio of clicks/appearences.
        I increase the bet by 25% over the ratio, this is an arbitrary choice.
        The ratio of times_clicked/times_appeared can't be more than 1, but if
        it is 1, I want to bet .99 to at least make a profit of .01.
        Otherwise there is no data and the chance of a click is 50/50.
        """
        self.user_id = user_id
        # updates the number of times user has been selected
        # each entry in the dict will have the format
        # {user_id: [# of times selected, # of times clicked]}
        if user_id in self.user_dict:
            self.user_dict[user_id][0] += 1
        else:
            self.user_dict[user_id] = [1,0]
        # tracking times clicked/times appeared and using this to value bet
        times_appeared = self.bidamt = self.user_dict[self.user_id][0]
        times_clicked = self.bidamt = self.user_dict[self.user_id][1]
        # if they have clicked I want to favor betting
        if times_clicked > 0:
            if times_clicked/times_appeared * 1.25 < 1:
                self.bidamt = times_clicked/times_appeared * 1.25
            elif times_clicked/times_appeared == 1:
                self.bidamt = .99
            else:
                self.bidamt = times_clicked/times_appeared
        # if they haven't clicked, there is no data so chances are 50/50
        elif self.bidamt < .5:
            self.bidamt = .5
        return round(self.bidamt,3)

    def notify(self, auction_winner, price, clicked):
        """Docstring for testing"""
        self.auction_winner = auction_winner
        self.clicked = clicked
        if self.clicked == True:
            # updates if the user clicked
            # this is the second entry in the value list
            self.user_dict[self.user_id][1] += 1
        elif price <= .94:
            self.bidamt = price + .05
