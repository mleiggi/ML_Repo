from wordscore import *

def run_scrabble(tiles):
    """
    run_scrabble takes an argument called tiles. tiles must be a string length
    2-7 consisting of only letters and '?' or '*'. It then calls the function
    score_word that returns a tuple with the words possible, their scores, and
    the total number of words.
    """
    acceptable_entries = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ?*' # allowed entries 
    # below are some checks for common issues that may arise
    if type(tiles) != str:
        return str("The entry must be a string. If you want to enter the letters a,b,c you ned to enter 'abc'. You may use single or double quotes.")
    tiles = tiles.upper()
    if len(tiles) not in range(2,8):
        return str("Sorry, your input must be between 2 and 7 characters.")
    if tiles.count('?') > 1 or tiles.count('*') > 1:
        return str("You had too many '*' or '?' entries. You may only have one of each!")
    for tile in tiles:
        if tile not in acceptable_entries:
            return str("Sorry, your entry must be letters only, or '*' and '?' for blank tiles.")
    else:
        # finally a try for errors that were not predicted.
        try:
            return score_word(tiles)
        except:
            return str("Something else went wrong!")
 
if __name__ == '__main__':
    result = run_scrabble('?a')
    print(result)
    

